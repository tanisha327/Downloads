
 ==============================================================

          Exeinfo PE v0.0.4.4 - 966 + 54 signatures

           with partial support for 64 bit PE files

           Ext_detector.dll - ver.0.3.9.9

 ==============================================================


included : 
  
   userDB.txt        - 4513 Signatures in list  ( fixed version )
   ( ExeinfoPe check only EP offset bytes , max 4700 signatures )

   
   Languages : neutral v042 , China Big5 / China Simplified / Rus v0.0.4.1


plugins :

  not included / compatible with old PEid.exe


added :


 - new signatures , old signatures updated ( newer version update )
 - added SFX detection on PureBasic v4.20 
 - updated 7-Zip Sfx Archive
 - on Windows v10 - config - shell integration support !
 - many small changes ...





 Exeinfo Pe  - License status 	 Freeware for non-commercial use




ExeinfoPe - Console Mode info  :

if you need change log file "!ExEinfo-Multiscan.log" to your path/file

try : exeinfope.exe FileName* /s /log:C:\MyLogFile.txt
  For long file path/names 
try : exeinfope.exe FileName* /s /log:"C:\My Dir 1 2 3\LogFile.txt"



 more info 

 try : exeinfope.exe /?




 ==============================================================


   A.S.L (c) asl@onet.eu - www.exeinfo.xn.pl - 2016.11.04


 ==============================================================

